module.exports = {
  lintOnSave: false,
  devServer: {
    open: false, // auto open brower 项目启动后自动打开浏览器...
    disableHostCheck: false,
    host: '0.0.0.0',
    port: 8085, // 修改端口号
    https: false,
    hotOnly: false, 
    proxy: { // string | Object 解决跨域问题 /api 会自己添加上去
      '/api': {
        target: process.env.VUE_BASE_URL, // 对应自己的 跨域地址 即请求的后端地址
        changeOrigin: true,
        ws: true
      }
    }
  }
}
