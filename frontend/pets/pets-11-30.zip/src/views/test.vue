<template>
<div class="test">
  <div class="circle">
    <div class="box">

    </div>
  </div>
</div>
</template>

<script lang="ts">
import {
  defineComponent
} from 'vue'

export default defineComponent({
  name: 'test',
  components: {
    setup(props) {

    }
  }
})
</script>

<style scoped>

</style>
