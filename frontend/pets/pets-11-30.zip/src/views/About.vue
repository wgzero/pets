<template>
<div class="about">
  <h1>This is an about page</h1>
  <van-button type="primary">主要按钮</van-button>
  <a href="http://192.168.100.19:8086/#/test">跳转页面</a><br />
  <i class="iconfont iconzhonglei-copy"></i>
</div>
</template>


<style lang="less" scoped>
@import "../assets/style/common";
.about{
  color: red;
  background: @bgColor;
}
</style>