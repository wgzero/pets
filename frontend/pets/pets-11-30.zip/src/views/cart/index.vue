<template>
  <div class="cart">
    <div>cart</div>
    <home-footer></home-footer>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import homeHeader from "@/components/header.vue"
import homeFooter from "@/components/footer.vue"

export default defineComponent({
  name: 'cart',
  components: {
    homeHeader,
    homeFooter
  }
})
</script>

<style lang="less" scoped>

</style>
