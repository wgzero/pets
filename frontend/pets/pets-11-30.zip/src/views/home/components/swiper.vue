<template>
  <div class="swiper">
    <van-swipe :autoplay="3000" indicator-color="#25A5EB">
      <van-swipe-item>
        <img src="@/assets/imgs/1.jpg" alt="">
      </van-swipe-item>
      <van-swipe-item>
        <img src="@/assets/imgs/1.jpg" alt="">
      </van-swipe-item>
      <van-swipe-item>
        <img src="@/assets/imgs/1.jpg" alt="">
      </van-swipe-item>
    </van-swipe>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { getBanner } from "@/api/index"

export default defineComponent({
  name: 'swiper',
  props: {
    list: {
      type: Array,
      required: true // 必传
    }
  },
  components: {
  }
})
</script>

<style lang="less" scoped>
.swiper{
  width: 100%;
  height: 150px;
  padding-top: 55px;
  box-sizing: border-box;
    img {
      width: 100%;
      height: 150px;
      display: block;
    }
  
}

</style>
