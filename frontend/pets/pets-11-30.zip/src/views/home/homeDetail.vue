<template>
  <div class="homeDetail">
    <detail-header title="图片详情">
      <template #headerLeft>
        <div class="detail-left" @click="handleBack">
          <i class="iconfont iconfanhui backIcon"></i>
        </div>
      </template>
    </detail-header>
    <div class="detail-body">
      <div class="detail-body-header">
        <img class="detail-header-imgs" src="@/assets/imgs/cat.jpg" alt="">
        <div class="detail-header-right">
          <div class="detail-header-info">
            <div class="detail-header-title">图片标题</div>
            <div class="detail-preview">
              <i class="iconfont iconliulan detail-eyes"></i>
              <div class="detail-header-num">10</div>
            </div>
          </div>
          <div class="detail-header-name">
            猫咪
          </div>
          <div class="detail-header-content">
            活动婚纱店哈哈大撒哈哈哈的撒火红的萨活动啥都好说记得撒大所大大所多
          </div>
        </div>
      </div>
      <div class="detail-msg">
        <div class="detail-mid-title">留言</div>
        <div class="detail-msg-content">这是猫咪好可爱呀</div>
      </div>
      <div class="detail-comment">
        <div class="detail-comment-top">
          <div class="detail-comment-top-left">萌友评论</div>
          <div class="detail-comment-top-right">评论条数: 120</div>
        </div>
        <div class="detail-comment-info" v-for="(item, index) of 5" :key="index">
          <div class="detail-comment-all">
            <div class="detail-comemnt-all-left">
              <img src="@/assets/imgs/1.jpg" class="detail-comment-imgs" alt="">
              <div class="detail-comment-name">沐沐</div>
            </div>
            <div class="detail-comemnt-all-right">
              <i class="iconfont icondianzan_active detail-star"></i>
              <div class="detail-comemnt-num">20</div>
            </div>
          </div>
          <div class="detail-comment-msg">
            大萨达奥多所所大大所多哒哒哒哒打撒所大多撒奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥大
            大萨达奥多所所大大所多哒哒哒哒打撒所大多撒奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥奥大
          </div>
        </div>
      </div>
      <div class="detail-comment-more">
        <div class="detail-comment-load">
          更   多
        </div>
      </div>
    </div>
    <div class="detail-btm">
      <div class="detail-btm-icons">
        <div class="detail-btm-left-01">
          <i class="iconfont icondianzan_active detail-btn-icons-01"></i>
          <span class="detail-btm-star-01">点赞</span>
        </div>
        <div class="detail-btm-left">
          <i class="iconfont iconshoucang-copy detail-btn-icons"></i>
          <span class="detail-btm-star">收藏</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive } from 'vue'
import { useRouter } from "vue-router" 
import detailHeader from "@/components/header.vue"

export default defineComponent({
  name: 'homeDetail',
  components: {
    detailHeader
  },
  setup(props, context){
    const state = reactive({
      route: ""
    })
    let router = useRouter()
    const handleBack = () => {
      // console.log("xxx", router)
      router.go(-1)
    }

    return {
      state,
      handleBack
    }
  }
})
</script>

<style lang="less" scoped>
@import "@/assets/style/common";
.homeDetail{
  width: 100%;
  height: 100%;
  background: @detailBg;
  .backIcon{
    font-size: 20px;
    display: block;
    text-align: center;
    line-height: 55px;
  }
  .detail-body{
    width: 100%;
    // height: 1000px;
    background: @detailBg;
    padding-top: 55px;
    .detail-body-header {
        width: 100%;
        display: flex;
        justify-content: space-evenly;
        margin-top: 28px;
        .detail-header-imgs {
            width: 40%;
            height: 240px;
            border-radius: 20px;
        }
        .detail-header-right {
            width: 40%;
            .detail-header-info {
                display: flex;
                justify-content: space-between;
                .detail-header-title {
                    font-size: 20px;
                    color: #333;
                }
                .detail-preview {
                    display: flex;
                    .detail-eyes {
                        display: block;
                        text-align: center;
                        margin: auto;
                        font-size: 18px;
                        color: #bbb;
                    }
                    .detail-header-num {
                        font-size: 16px;
                        margin: auto;
                        padding-left: 5px;
                        color: #bbb;
                    }
                }
            }
            .detail-header-name {
                line-height: 40px;
                font-size: 16px;
                color: #666;
            }
            .detail-header-content {
                font-size: 15px;
                overflow: hidden;
                color: #888;
            }
        }
    }
    .detail-msg{
      margin: 50px auto;
      width: 80%;
      .detail-mid-title {
          font-size: 20px;
      }
      .detail-msg-content {
          width: 100%;
          height: 120px;
          background: white;
          margin-top: 16px;
          border-radius: 20px;
          padding: 8px 12px;
          box-sizing: border-box;
          font-size: 16px;
          font-weight: 500;
          color: #333;
      }
    }
    .detail-comment{
      margin: auto;
      width: 80%;
      .detail-comment-top {
          display: flex;
          justify-content: space-between;
          font-size: 20px;
          .detail-comment-top-right {
              font-size: 16px;
              display: flex;
              flex-direction: column-reverse;
              color: #777;
          }
      }
      .detail-comment-info {
          width: 100%;
          height: 136px;
          background: white;
          border-radius: 20px;
          margin-top: 20px;
          padding: 12px 30px;
          box-sizing: border-box;
        .detail-comment-all {
          width: 100%;
          box-sizing: border-box;
          display: flex;
          justify-content: space-between;
            .detail-comemnt-all-left {
                display: flex;
                .detail-comment-imgs{
                  display: block;
                  width: 30px;
                  height: 30px;
                  border-radius: 50%;
                  margin-right: 8px;
                }
                .detail-comment-name {
                    color: #333;
                    font-size: 16px;
                    margin: auto;
                }
            }
            .detail-comemnt-all-right {
                display: flex;
                .detail-star {
                  display: block;
                  margin: auto;
                  color: #666;
                  padding-right: 6px;
                }
                .detail-comemnt-num {
                    font-size: 16px;
                    margin: auto;
                }
            }
        }
        .detail-comment-msg {
            margin-top: 10px;
            font-size: 14px;
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            color: #999;
        }
      }
    }
    .detail-comment-more {
        margin-top: 30px;
        padding-bottom: 90px;
        width: 100%;
        height: 42px;
        display: flex;
        justify-content: center;
        .detail-comment-load {
          width: 80%;
          display: flex;
          background: @bgColor;
          justify-content: center;
          border-radius: 30px;
          line-height: 42px;
          font-size: 18px;
          color: @white;
      }
    }
  }
  .detail-btm {
    position: fixed;
    width: 100%;
    bottom: 0;
    border-top: 1px solid #ccc;
    background: @detailBg;
    height: 70px;
    .detail-btm-icons {
      display: flex;
      justify-content: space-evenly;
      width: 100%;
      margin-top: 14px;
      .detail-btm-left {
          width: 30%;
          height: 38px;
          background: white;
          text-align: center;
          border-radius: 21px;
          line-height: 34px;
          .detail-btn-icons {
              font-size: 16px;
              color: @bgColor;
          }
          .detail-btm-star {
              font-size: 14px;
              margin-left: 6px;
              color: @bgColor;
          }
      }
      .detail-btm-left-01{
          width: 30%;
          height: 38px;
          background: @bgColor;
          text-align: center;
          border-radius: 21px;
          line-height: 34px;
          .detail-btn-icons-01 {
              font-size: 16px;
              color: @white;
          }
          .detail-btm-star-01 {
              font-size: 14px;
              margin-left: 6px;
              color: @white;
          }
      }
    }
  }
}
</style>
