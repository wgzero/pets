<template>
  <div class="category">
    <div class="category-search">
      <van-search
        v-model="state.value"
        shape="round"
        background="#25A5EB"
        placeholder="请输入搜索关键词"
        @search="onSearch"
      >
      </van-search>
    </div>
    <div class="category-body">
      <van-tree-select
        v-model:active-id="state.activeId"
        v-model:main-active-index="state.activeIndex"
        :items="state.items"
        height="90vh"
      >
        <template #content>
          <div class="category-one" v-if="state.activeIndex == 0">
            <div class="category-title">
              动物类型(猫)
            </div>
            <div class="category-img-name">
              <div class="category-info" v-for="(item, index) of 5" :key="index">
                <img class="category-img" src="@/assets/imgs/1.jpg" alt="">
                <div class="category-name">旺财</div>
              </div>
            </div>
            <div class="category-line"></div>
          </div>
          <div class="category-one" v-if="state.activeIndex == 1">
            222
          </div>
        </template>
      </van-tree-select>
    </div>
    <home-footer></home-footer>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import homeFooter from "@/components/footer.vue"

export default defineComponent({
  name: 'category',
  components: {
    homeFooter
  },
  setup(props, context){
    const state = reactive({
      value: "",
      items: [{ text: '分组 1' }, { text: '分组 2' }],
      activeId: 1,
      activeIndex: 0
    })
    const onSearch = () => {
      console.log("666", state.value)
    }
    return {
      state,
      onSearch
    }
  }
})
</script>

<style lang="less" scoped>
@import "@/assets/style/common";
.category{
  width: 100%;
  .category-search{
    width: 100%;
    height: 55px;
    .van-search{
      height: 55px;
    }
  }
  .category-body{
    width: 100%;
    height: 100%;
    .category-one{
      margin-top: 20px;
      .category-title {
          text-align: center;
          font-size: 14px;
          color: #666;
      }
      .category-img-name {
          display: flex;
          flex-wrap: wrap;
          justify-content: end;
          margin: 10px;
          .category-info {
              width: 24.6%;
              text-align: center;
              border: 1px solid #ccc;
              margin: 10px 10px;
              border-radius: 5px;
              box-shadow: 0 2px 6px 0 #ccc;
              .category-img {
                  width: 36px;
                  height: 40px;
                  border-radius: 6px;
                  margin-top: 6px;
              }
              .category-name {
                  font-size: 12px;
                  line-height: 20px;
                  color: #666;
              }
          }
      }
      .category-line {
          width: 160px;
          height: 1px;
          background: #f1f1f1;
          margin: 30px auto;
      }
    }
  }
}
.category ::v-deep .van-sidebar-item--select::before {
    background-color: @bgColor;
}
.category ::v-deep .van-tree-select__nav-item {
    text-align: center;
}
.category ::v-deep .van-tree-select__nav {
    flex: none;
    width: 100px;
}
</style>
