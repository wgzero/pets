<template>
  <div class="my">
    <div>my</div>
    <home-footer></home-footer>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted } from 'vue'
import homeHeader from "@/components/header.vue"
import homeFooter from "@/components/footer.vue"
import { getBanner } from "@/api/index"

export default defineComponent({
  name: 'my',
  components: {
    homeHeader,
    homeFooter
  },
  setup(props, context){
    onMounted(() => {
      getBanner().then(res => {
        console.log("res===", res)
      })
    })
  }
})
</script>

<style lang="less" scoped>

</style>
