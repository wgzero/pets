<template>
  <div class="upload">
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'uploadFile',
  components: {
  }
})
</script>

<style lang="less" scoped>

</style>
