import { createApp } from 'vue'
import { Button, Swipe, SwipeItem, List, Cell, Search, TreeSelect } from 'vant'
import App from './App.vue'
import router from './router'
import store from './store'
// 引入vant的css样式
import "vant/lib/index.css"
// 移动端适配
import 'amfe-flexible/index.js'
// 阿里图标库
import "./assets/iconfont/iconfont.css"

const app = createApp(App)
app.use(Button)
app.use(Swipe)
app.use(SwipeItem)
app.use(List)
app.use(Cell)
app.use(Search)
app.use(TreeSelect)

app.use(store).use(router).mount('#app')
