import request from "@/request/request"

const BSL = "/api"

const token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IjExIiwicGFzc3dvcmQiOiIwZjlhMjNkOTRlNjc5MGY5OGM0MTJjYmI3OWUyZTEwNWVlOTNlYzRlIiwiaWF0IjoxNjA2NzIyMTY4LCJleHAiOjE2MDY3MjU3Njh9.B-Jo465KhHlZkY01hGKZCUWaKRwtaC1o0_o-CklFVhc"
// params data
export function getBanner(){
  return request({
    url: `${BSL}/getBanner`,
    method: 'get',
    headers: {
      Authorization: token
    }
  })
}