<template>
  <router-view/>
</template>

<style lang="less" scoped>

</style>
