import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import Home from '../views/Home.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  }
  ,
  {
    path: '/home',
    name: 'Home',
    component: () => import('../views/home/index.vue')
  },
  {
    path: '/category',
    name: 'Category',
    component: () => import('../views/category/index.vue')
  },
  {
    path: '/video',
    name: 'Video',
    component: () => import('../views/video/index.vue')
  },
  // 视频上传
  {
    path: '/videoUpload',
    name: 'videoUpload',
    component: () => import('../views/video/uploadFile.vue')
  },
  {
    path: '/cart',
    name: 'Cart',
    component: () => import('../views/cart/index.vue')
  },
  {
    path: '/my',
    name: 'My',
    component: () => import('../views/my/index.vue')
  },
  {
    path: '/test',
    name: 'test',
    component: () => import('../views/test.vue')
  },
  // 图片详情
  {
    path: '/homeDetail',
    name: 'homeDetail',
    component: () => import('../views/home/homeDetail.vue')
  },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
